jQuery.sap.declare("com.sap.ztestf4mktarea.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("com.sap.ztestf4mktarea.Component", {
	metadata: {
		"manifest": "json"
	}
});